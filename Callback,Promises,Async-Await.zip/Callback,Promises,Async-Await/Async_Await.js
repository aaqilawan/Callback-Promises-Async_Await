const first = new Promise((resolve, reject) => {
    setTimeout(() => {
        const roll_no = [1, 2, 3, 4, 5];
        resolve(roll_no);
    }, 2000);
});

const second= new Promise((resolve,reject) => {
    setTimeout(() => {
      const data = {
          name : 'Aqil',
          age : 25
      }  
      resolve(data);
    },2000);
});

async function abc() {
    let fst = await first;
    console.log(fst);
    let snd = await second;
    console.log(snd);
    let res =await fetch('https://jsonplaceholder.typicode.com/users');
    let jsonFile = await res.json();
    console.log(jsonFile);
       
}

 abc();