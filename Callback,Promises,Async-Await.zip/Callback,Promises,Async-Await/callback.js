const second = (csallback) =>{
    setTimeout(() => {
        const data = {name:"Aqil",age:25};
        console.log(data);
        callback();
        
    }, 2000);
}
const first = () =>{
    setTimeout(() => {
        const roll_no = [1, 2, 3, 4, 5];
        console.log(roll_no);
    }, 1000);
}

second(first);

